#include <iostream>
#include <string>
#include <cassert>

using namespace std;

/////////////////////////
//Ide dolgozz!!
////////////////////////

#ifndef TEST_BIRO
int main(){

  //Telepes konstruktor
  /*
    Telepes t1;
    assert(t1.getNev() == "");
    assert(t1.getSzulBolygo() == "");
    assert(t1.getBolygo() == "");
    assert(t1.getEro() == 1);

    t1.setSzulBolygo("Mars");
    t1.setBolygo("Venus");
    t1.setNev("Jevgenyij Anyegin");
    t1.setEro(10);
    assert(t1.getNev() == "Jevgenyij Anyegin");
    assert(t1.getSzulBolygo() == "Mars");
    assert(t1.getBolygo() == "Venus");
    assert(t1.getEro() == 10);
   */

  //Telepes parameteres konstruktor
  /*
    const Telepes t1("Franz Kafka", "Mars", "Venus", 50);
    assert(t1.getNev() == "Franz Kafka");
    assert(t1.getSzulBolygo() == "Mars");
    assert(t1.getBolygo() == "Venus");
    assert(t1.getEro() == 50);
   */

  //Telepes parameteres konstruktor 2
  /*
    const Telepes t1("Kurt Vonnegut", "Venus", 4);
    assert(t1.getNev() == "Kurt Vonnegut");
    assert(t1.getSzulBolygo() == "Venus");
    assert(t1.getBolygo() == "Venus");
    assert(t1.getEro() == 4);

    const Telepes t2("Kurt Vonnegut", "Venus");
    assert(t2.getNev() == "Kurt Vonnegut");
    assert(t2.getSzulBolygo() == "Venus");
    assert(t2.getBolygo() == "Venus");
    assert(t2.getEro() == 1);
   */

  //Kivandorlo teszt
  /*
    const Telepes t1("Franz Kafka", "Mars", "Px-2312", 50); //Kafka kivandorlo
    assert(t1.kivandorlo());
   */

  //Munkavegzes teszt
  /*
    const Telepes t1("Kovacs Geza", "Uranus", "Px-2312", 2);
    string munkak = "b1;b22;c3;x823";
    t1.dolgozik(munkak);
    assert(munkak == "c3;x823");
   */

  return 0;
}
#endif