#include <iostream>
#include <stdexcept>
#include <cassert>

using namespace std;

//=== Teszteles bekapcsolasa kikommentezessel
//
//=== Teszteles bekapcsolas vege


/////////////////////////
//Ide dolgozz!!
////////////////////////



#ifndef TEST_BIRO

int main() {

  /*
  cout << "1-es feladat tesztelese" << endl;
  int m = count_mM();
  cout << "A beolvasott m és M karaketerk szama: " << m << endl;
  */


  /*cout << "2-es feladat tesztelese" << endl;
  string reps = repeater();
  cout << reps << endl;*/

  /*cout << "3-as feladat tesztelese" << endl;
  string multi1 = multiplier(1);
  assert(multi1 == "3");*/

  /*cout << "4-es feladat tesztelese" << endl;
  int min = strmin("3", "4");
  assert(min == 3);
  min = strmin("Harry", "Potter");
  assert(min == -999);
  min = strmin("-3", "szappanos bukta");
  assert(min == -3);*/
  
  return 0;

}
#endif