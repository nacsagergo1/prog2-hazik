#include <iostream>
#include <string>
#include <cassert>
#include <vector>

using namespace std;

/////////////////////////
//Ide dolgozz!!
////////////////////////


int main(){

  //alap kutya
  {
    /*
    const Kutya k("Lassie", 3);
    assert(k.getNev() == "Lassie");
    assert(k.getKor() == 3);
    */
  }
  
  //alap kutya pedigre
  {
    /*
    const Kutya k("Lassie", 3);
    string s = k.pedigre();
    assert(s == "nev:Lassie, kor:3 ev");
    */
  }
  
  //alap kutya terel
  {
    /*
    const Kutya k("Lassie", 3);
    vector<string> dinamikus_nyaj = k.terel({"Frici", "Julcsa", "Gyuri", "Margit"});
    assert(dinamikus_nyaj[3] == "Margit");
    */
  }

  //test border collie
  {
    /*
    const BorderCollie bc("Jess", 13, 5);
    assert(bc.getNev() == "Jess");
    assert(bc.getKor() == 13);
    assert(bc.getTereloKapacitas() == 5);
    */
  }
  
  //pedigre border collie
  {
    /*
    const Kutya* bc = new BorderCollie("Jess", 13, 5);
    string s = bc->pedigre();
    assert(s == "nev:Jess, kor:13 ev, faj:border collie, terelo kapacitas:5 db birka");
    delete bc;
    */
  }
  

  //terel border collie
  {
    /*
    const Kutya* bc = new BorderCollie("Jess", 13, 3);
    vector<string> nyaj = {"Frici", "", "Julcsa", "Gyuri", "", "Margit"};
    vector<string> dinamikus_nyaj = bc->terel(nyaj);
    assert(dinamikus_nyaj[0] == "Frici");
    assert(dinamikus_nyaj[1] == "Julcsa");
    assert(dinamikus_nyaj[2] == "Gyuri");
    assert(dinamikus_nyaj[3] == "");//terelokapacitas!
    assert(dinamikus_nyaj[4] == "");
    assert(dinamikus_nyaj[5] == "Margit");
    */
  }

  return 0;
}
