#include <iostream>
#include <string>
#include <cassert>
#include <vector>
#include <map>
#include <set>

using namespace std;


/////////////////////////
//Ide dolgozz!!
////////////////////////


#ifndef TEST_BIRO
int main(){

  //telepes osztaly tesztek
  /*
    Telepes t1;
    assert(t1.getNev() == "");
    assert(t1.getSzulBolygo() == "");
    assert(t1.getBolygo() == "");
    assert(t1.getEro() == 1);
    assert(!t1.isVegan());

    t1.setSzulBolygo("Mars");
    t1.setBolygo("Venus");
    t1.setNev("Jevgenyij Anyegin");
    t1.setEro(10);
    t1.setVegan(true);
    assert(t1.getNev() == "Jevgenyij Anyegin");
    assert(t1.getSzulBolygo() == "Mars");
    assert(t1.getBolygo() == "Venus");
    assert(t1.getEro() == 10);
    assert(t1.isVegan());
  */



  //kolonia letelepszik tesztek
  /*
    Kolonia k("Kolonia1", "Mars");
    Telepes t1;
    t1.setNev("Janos");
    t1.setEro(5);
    t1.setVegan(true);
    k.letelepszik(t1);
    assert(k.getLetszam() == 1);

    Telepes t2;
    t2.setNev("Juli");
    t2.setEro(3);
    t2.setVegan(false);
    k.letelepszik(t2);
    assert(k.getLetszam() == 1); // Juli nem lett telepes, mert a kolónia vegán

    for (int i = 0; i < 24; ++i) {
    Telepes t;
    t.setNev("Telepes" + std::to_string(i));
    t.setEro(2);
    t.setVegan(true);
    k.letelepszik(t);
    }
    assert(k.getLetszam() == 25);

    Telepes t26;
    t26.setNev("Telepes26");
    t26.setEro(4);
    t26.setVegan(true);
    k.letelepszik(t26); // Kolónia megtelt
    assert(k.getLetszam() == 25);
  */



  //kolonia nevsor teszt
  /*
    Kolonia k("Kolonia1", "Mars");
    Telepes t1;
    t1.setNev("Janos");
    k.letelepszik(t1);

    Telepes t2;
    t2.setNev("Juli");
    k.letelepszik(t2);

    Telepes t3;
    t3.setNev("Julia");
    k.letelepszik(t3);

    Telepes t4;
    t4.setNev("Janos");
    k.letelepszik(t4); // Duplicate

    k.nevsor(); // Janos Juli Julia
  */



  //kolonia vegan teszt
  /*
    Kolonia k("Anarchy for all!", "Mars");
    assert(!veganE(k));

    Telepes t;
    t.setVegan(true);
    k.letelepszik(t);
    assert(veganE(k));
  */


 
  //kolonia legerosebb teszt
  /*
    Kolonia k("Kolonia1", "Mars");
    Telepes t1;
    t1.setNev("Janos");
    t1.setEro(5);
    k.letelepszik(t1);

    Telepes t2;
    t2.setNev("Juli");
    t2.setEro(3);
    k.letelepszik(t2);

    Telepes t3;
    t3.setNev("Julia");
    t3.setEro(8);
    k.letelepszik(t3);

    assert(k.legerosebb() == 8);
  */


  //kolonia szamol teszt
  /*
    Kolonia k("Kolonia1", "Mars");
    Telepes t1;
    t1.setNev("Janos");
    t1.setSzulBolygo("Mars");
    k.letelepszik(t1);

    Telepes t2;
    t2.setNev("Juli");
    t2.setSzulBolygo("mars");
    k.letelepszik(t2);

    Telepes t3;
    t3.setNev("Julia");
    t3.setSzulBolygo("Venus");
    k.letelepszik(t3);

    assert(k.szamol("Mars") == 2);
  */


  
  //kolonia eroHisztogram teszt
  /*
    Kolonia k("Kolonia1", "Mars");
    Telepes t1;
    t1.setNev("Janos");
    t1.setEro(5);
    k.letelepszik(t1);

    Telepes t2;
    t2.setNev("Juli");
    t2.setEro(2);
    k.letelepszik(t2);

    Telepes t3;
    t3.setNev("Julia");
    t3.setEro(1);
    k.letelepszik(t3);

    Telepes t4;
    t4.setNev("Janet");
    t4.setEro(1);
    k.letelepszik(t4);

    Telepes t5;
    t5.setNev("John");
    t5.setEro(5);
    k.letelepszik(t5);

    auto hist = k.eroHisztogram();
    assert(hist[1] == 2);
    assert(hist[2] == 1);
    assert(hist[5] == 2);
  */


  return 0;
}
#endif