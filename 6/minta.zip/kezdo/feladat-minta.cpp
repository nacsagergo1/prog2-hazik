#include <iostream>
#include <vector>
#include <functional>
#include <algorithm>

using namespace std;


int main() {
    // 1. feladat: Etel osztály tesztelése
    //Etel etel1;  // Default konstruktor
    //Etel etel2("Pizza", "Sonkás-sajtos pizza", 1200);  // Paraméteres konstruktor

    //std::cout << "Etel1 neve: " << etel1.get_nev() << ", leírása: " << etel1.get_leiras() << ", ára: " << (unsigned int)etel1 << "\n";
    //std::cout << "Etel2 neve: " << etel2.get_nev() << ", leírása: " << etel2.get_leiras() << ", ára: " << (unsigned int)etel2 << "\n";

    // 2. feladat: Menu osztály tesztelése
    //Etel etel3("Leves", "Zöldségleves", 600);
    //Etel etel4("Tészta", "Spagetti bolognese", 1500);
    //Menu menu1("Ebédmenü", "3 fogásos ebéd", etel2, etel3, etel4);

    //std::cout << "Menu neve: " << menu1.get_nev() << "\n";
    //std::cout << "Menu ára: " << (unsigned int)menu1 << "\n";  // 10% kedvezmény

    // 3. feladat: Vendeglo osztály tesztelése
    //Vendeglo vendeglo;
    //vendeglo << etel3 << etel2 << etel4 << menu1;

    //try {
    //    std::cout << "A vendéglő legolcsóbb étele: " << vendeglo.operator Etel().get_nev() << "\n";
    //} catch (const std::exception& e) {
    //    std::cout << "Hiba: " << e.what() << "\n";
    //}

    return 0;
}